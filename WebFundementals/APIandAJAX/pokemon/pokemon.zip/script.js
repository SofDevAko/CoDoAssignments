$(document).ready(function(){
    for(i=1; i<152; i++){
       $('body').append("<img src='http://pokeapi.co/media/img/"+i+".png/'/>")     
    }
})
